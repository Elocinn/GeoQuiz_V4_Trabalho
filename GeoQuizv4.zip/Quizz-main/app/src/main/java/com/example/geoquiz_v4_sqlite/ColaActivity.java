package com.example.geoquiz_v4_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ColaActivity extends AppCompatActivity {

    // Constantes para identificar as extras enviadas pela MainActivity
    private static final String EXTRA_REPOSTA_E_VERDADEIRA = "com.example.geoquiz_v3.reposta_e_verdadeira";
    private static final String EXTRA_RESPOSTA_FOI_MOSTRADA= "com.example.geoquiz_v3.reposta_foi_mostrada";
    // Constante para identificar o valor da chave "colou" no Bundle
    private static final String CHAVE_COLOU = "CHAVE_COLOU";
    // Variáveis de instância
    private boolean mRespostaEVerdadeira;
    private TextView mTextViewResposta;
    private Button mBotaoMostraResposta;
    private boolean mColou = false;  // registra se o usuário viu ou não a reposta (para recuperar o estado em caso de rotação
                                     // do dispositivo)
    @Override
    protected void onCreate(Bundle instanciaSalva) {
        super.onCreate(instanciaSalva);
        setContentView(R.layout.activity_cola);

        /* recupera estado da activivty em caso de rotação do dispositivo */
        if (instanciaSalva != null) {
            mColou = instanciaSalva.getBoolean(CHAVE_COLOU);
            setRespostaFoiMostrada(mColou);
        }
        // Obtém a resposta da pergunta atual
        mRespostaEVerdadeira = getIntent().getBooleanExtra(EXTRA_REPOSTA_E_VERDADEIRA, false);
        // Obtém os componentes da interface
        mTextViewResposta = (TextView) findViewById(R.id.view_texto_resposta);
        // Define o evento de clique no botão "Mostra resposta"

        mBotaoMostraResposta = (Button) findViewById(R.id.botao_mostra_resposta);
        mBotaoMostraResposta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Registra que o usuário viu a resposta
                mColou = true;

                // Exibe a resposta da pergunta
                if (mRespostaEVerdadeira) {
                    mTextViewResposta.setText(R.string.botao_verdadeiro);
                } else
                    mTextViewResposta.setText(R.string.botao_falso);

                // Envia um intent com a resposta foi mostrada
                setRespostaFoiMostrada(true);
            }
        });
    }

    private void setRespostaFoiMostrada(boolean repostaFoiMostrada) {
        // Cria um intent para retornar
        Intent dados = new Intent();

        // Adiciona a extra "resposta_foi_mostrada" ao intent
        dados.putExtra(EXTRA_RESPOSTA_FOI_MOSTRADA, repostaFoiMostrada);

        // Define o resultado da atividade
        setResult(RESULT_OK, dados);
    }

    public static Intent novoIntent(Context packageContext, boolean respostaEVderdadeira) {
        Intent intent = new Intent(packageContext, ColaActivity.class);
        intent.putExtra(EXTRA_REPOSTA_E_VERDADEIRA, respostaEVderdadeira);
        return intent;
    }
    public static boolean foiMostradaResposta(Intent result){
        return result.getBooleanExtra(EXTRA_RESPOSTA_FOI_MOSTRADA, false);
    }

    /* salva estado da activivty em caso de rotação do dispositivo */
    public void onSaveInstanceState(Bundle instanciaSalva) {
        super.onSaveInstanceState(instanciaSalva);
        //Log.i(TAG, "onSaveInstanceState()");
        instanciaSalva.putBoolean(CHAVE_COLOU, mColou);
    }
}